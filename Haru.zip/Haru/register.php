<?php

$title = 'Registeration';

require 'template/header.php'

?>


<?php


if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $FNAME = $_POST['fname'];
    $LNAME = $_POST['lname'];
    $EMAIL = $_POST['email'];
    $PASSWORD = $_POST['password'];
    $PHONE = $_POST['phone'];
    $COUNTRY = $_POST['country'];
    $CITY = $_POST['city'];
    $ADDRESS = $_POST['address'];
    $BN = $_POST['bn'];


    require 'database/connection.php';
    $conn = new mysqli('localhost','root','','haru_online');
    $isexist =  $conn -> query("SELECT email from customer where email = '$EMAIL' limit 1 ");


    if($isexist -> num_rows)
        $success = "<p class='alert alert-danger my-3 '>Email is Already Exist</p>";


    else {


    $result = $pdo -> query("INSERT INTO customer (email,first_name,last_name,password,phone,country,city,street,building_number) VALUES ('$EMAIL','$FNAME','$LNAME','$PASSWORD','$PHONE','$COUNTRY','$CITY','$ADDRESS','$BN')",MYSQLI_USE_RESULT);

    if($result) {
        $success = "<p class='alert alert-success my-3 '>Your Register Have Been Success</p>";
        header("Location: index.php");



    }
}
}

?>
<div class="container my-5 py-5">



    <?php if(isset($success)) echo $success;?>

<form action="register.php" method="POST">
    <div class="row mb-3">
        <div class="col">
            <input type="text" class="form-control" name="fname" placeholder="First name" aria-label="First name" required>
        </div>
        <div class="col">
            <input type="text" class="form-control" name ="lname"placeholder="Last name" aria-label="Last name " required>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col">
            <input type="email" class="form-control" name="email" placeholder="email@mail.com" aria-label="email" required>
        </div>
        <div class="col">
            <input type="tel" class="form-control" name="phone" placeholder="Phone" aria-label="phone" required>
        </div>
    </div>



    <div class="row mb-3">
        <div class="col">
            <input type="password" class="form-control" name="password" placeholder="Password" aria-label="password" required>
        </div>
        <div class="col">
            <input type="text" class="form-control" name="country" placeholder="Country" aria-label="Country" required>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col">
            <input type="text" class="form-control" name="address" placeholder="Address" aria-label="Address" required>
        </div>
        <div class="col">
            <input type="text" class="form-control" name="city" placeholder="City" aria-label="City" required>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col">
            <input type="text" class="form-control" name="bn" placeholder="Building Number" aria-label="Building Number">
        </div>

    </div>

    <button type="submit" class="btn btn-success  register-btn d-block w-100">Register</button>


</form>

</div>


<?php require 'template/footer.php' ?>