<?php 

$config = [
    'app_name' => 'Haru',
    'lang' => 'en',
    'dir' => 'ltr'
]


?>