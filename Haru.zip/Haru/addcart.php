<?php

$title = 'Addcart';

require 'template/header.php'

?>


<div class="addcard">
<div class="container">




    <?php
    require 'database/connection.php';
        $addcart = $pdo -> query("select * from category where number = $_GET[number]",MYSQLI_ASSOC);
        ?>
       <?php foreach ($addcart as  $card) { ?>

           <div class="left  ">
               <h4>Product Name: </h4>
               <p class="display-3" style="color:#ef5aa1;"><?php echo $card['name']?></p>
               <h4>Product Description: </h4>
               <p><?php echo $card['description']?></p>
               <h4>Product Price: </h4>
               <p class="display-4"  style="color:#ef5aa1;">$<?php echo $card['price']?></p>
               <button class="btn btn-outline-danger" style = "border-color: #ef5aa1; color: #ef5aa1; ">Add Card</button>
           </div>

           <div class="right">



                   <img src="<?php echo $card['image']?>" alt="image card" class="">

           </div>



       <?php } ?>







</div>



</div>