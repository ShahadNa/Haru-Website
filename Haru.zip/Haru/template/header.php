
<?php require 'config/app.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="config/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Arima+Madurai:wght@100;200;300;400;500;700&family=Yantramanav:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
    <!-- Font Awesome -->
    <title><?php echo $config['app_name'] . ' | ' . $title?></title>
    <link rel="stylesheet" href="template/css/header.css">
    <link rel="stylesheet" href="template/css/home.css">
    <link rel="stylesheet" href="template/css/footer.css">
    <link rel="stylesheet" href="template/css/categories.css">
    <link rel="stylesheet" href="template/css/addcard.css">


</head>
<body>
  <!--  Start Header -->

  <header>
    <div class="container">
    <nav>
       <img src="template/imgs/harulogo.png" alt="" > 
       <div class="links">

           <span class="burger-menu"><i class="fas fa-bars"></i></span>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="categories.php">Women</a></li>
            <li><a href="kids.php">Kids</a></li>
            <li><a href="addcart.php">Cart</a></li>
            <li><a href="#login">Login</a></li>
            <li><a href="#register">Register</a></li>
        </ul>

        </div>


    </nav>


    </div>
  </header>


  <!--  End Header -->
