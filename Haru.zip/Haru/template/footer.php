
<footer>
    <div class="container">
        <img src="template/imgs/harulogo.png" alt="footer-logo"/>
        <div class="haru">
            <h4>Haru</h4>
            <ul>
                <li><a href="">Contact Us</a></li>
                <li><a href="">About Us</a></li>
            </ul>
        </div>

        <div class="follow-us">
            <h4>Follow Us</h4>
            <ul>
                <li><a href="">Facebook</a></li>
                <li><a href="">Instagram</a></li>
            </ul>
        </div>
    </div>

    <p>All Right Reserved <?php echo date('Y');?> &copy; Haru</p>
</footer>

<script>
    let burgerMenu = document.querySelector('.burger-menu');
    let navUl = document.querySelector('header div.container nav div.links ul');

    burgerMenu.onclick = ()=> {
        if(navUl.style.display == 'flex') {
            navUl.style.animation = "slideUp 0.3s  linear forwards";

            setTimeout(()=> {
                navUl.style.display = 'none';
            },300)
        }
        else {
            navUl.style.animation = "slideDown 0.3s  linear forwards";
            navUl.style.display = 'flex';
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>