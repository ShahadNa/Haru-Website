<?php
$host = 'localhost';
$dbname = 'haru_online';
$connectionString= "mysql:host=$host;dbname=$dbname";
$username = 'root';
$password = '';
// to do a connection with the database
$pdo = new PDO($connectionString,$username,$password);
?>