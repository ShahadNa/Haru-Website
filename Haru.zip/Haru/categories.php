<?php
$title  = 'Women';

require 'template/header.php' ?>


<div class="categories">


    <div class="container">


                        <div class="women">

                            <?php
                            require 'database/connection.php';
                            $products = $pdo->query("select * from category where category like 'women'",MYSQLI_ASSOC);
                            ?>
                            <?php foreach($products as $product) { ?>

                                <div class="card" style="width: 18rem;">
                                    <img src="<?php echo $product['image']?>" class="card-img-top product-image" alt="...">
                                    <div class="card-body">

                                            <a href="addcart.php?number=<?php echo $product['number']?>" class="btn btn-primary">Show More</a>
                                        </div>
                                    </div>


                            <?php } ?>
                        </div>





    </div>

    </div>







<?php require 'template/footer.php'?>