<?php
$title  = 'Home';
require 'template/header.php' ?>


<div class="landing-page">

    <div class="container">
        <h1>Welecome In Haru Online</h1>
        <h2>Only For Women And Kids </h2>
        <button class="shop-now"><a href="categories.php" >Shop Now</a></button>
    </div>


</div>
















<?php include 'template/footer.php' ?>