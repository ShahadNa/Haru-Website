<?php
$title  = 'Login';
include 'template/header.php' ?>



<div class="card">


 <div class="container">

        <h1>Login Form</h1>


    <form action="login.php" method="post">

        <div class="form-floating mb-3">
            <input type="email" name="email" class="form-control" id="" placeholder="mail@email.com">
            <label for="email">Email Address</label>

        </div>

        <div class="form-floating mb-3">
            <input type="password" name="password" class="form-control" id=""  placeholder="password" >
            <label for="email">Password </label>
        </div>
    </form>



</div>
    </div>













<?php include 'template/footer.php' ?>